//
// Created by nezar on 12/29/2024.
//

#ifndef AVLTREE_H
#define AVLTREE_H

#define FALSE 0
#define TRUE 1

typedef struct Node *AVLTree;  //Structure containing all data needed per patient, with the left and right subtree pointers.
struct Node
{
    char fName[20];
    char lName[20];
    int birthDate[3];
    double height;
    int weight;
    double bmi;
    AVLTree equalBMI; // will be used to link patients with the same BMI.
    AVLTree left;
    AVLTree right;
    int treeHeight;
};

AVLTree CreateTree(void);
AVLTree MakeEmptyTree(AVLTree);
AVLTree InsertElement(char*, char*, int*, double, int, double, AVLTree);
AVLTree loadPatients(char* fileName);
void DisplayEquals(AVLTree);
void displayPatients(AVLTree);
AVLTree RotationRR(AVLTree);
AVLTree RotationLL(AVLTree);
AVLTree RotationLR(AVLTree);
AVLTree RotationRL(AVLTree);
int infoPatient(AVLTree, double);
AVLTree youngestPatient(AVLTree, AVLTree);
int AVLTreeHeight(AVLTree);
int Max(int, int);

#endif //AVLTREE_H
