//
// Created by nezar on 12/29/2024.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avltree.h"

int main()
{
   AVLTree myTree = loadPatients("patients.txt");
   int exit=FALSE, found;
   char command;
   double searchBMI;
   printf("Welcome to Patient Indexing!!!\n");
   while (!exit)
   {
      fflush(stdin);
      printf("-------Menu-------\n(1)Display the full index of patients\n(2)Display the details of the patients\n(3)Display the youngest patient\n(4)Exit\nEnter your option: ");
      scanf("%c", &command);
      fflush(stdin);
      switch (command)
      {
         case '1':
            printf("\n");
         displayPatients(myTree);
         printf("\n");
         break;
         case '2':
            do {
               fflush(stdin);
               printf("Enter patient's BMI: ");
               scanf("%lf",&searchBMI);
               found=infoPatient(myTree,searchBMI);
               if (found==-1)
                  printf("There is not an available patient who has a BMI of %.1lf",searchBMI); //will repeat asking the user until an existing BMI is found in the tree.
            } while (found==-1);
         break;
         case '3':
            AVLTree youngestP = youngestPatient(myTree, myTree); //passes 2 trees: one to traverse our avl tree, and one to keep track of the tree with the youngest patient (initially set to the root node).
         printf("Youngest patient is %s %s\n",youngestP->fName, youngestP->lName);
         break;
         case '4':
            exit = TRUE;
         break;
         default:
            printf("command not recognized\n");
         break;
      }
   }
   printf("\n");
   system("PAUSE");
   return 0;
}



