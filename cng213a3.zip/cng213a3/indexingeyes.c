//
// Created by nezar on 12/29/2024.
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "avltree.h"

AVLTree CreateTree(void)
{
    return NULL;
}

AVLTree MakeEmptyTree(AVLTree t)
{
    if (t != NULL)
    {
       MakeEmptyTree(t->left);
       MakeEmptyTree(t->right);
       free(t);
    }
    return NULL;
}

AVLTree InsertElement(char* fName,char* lName,int birthDate[3],double height,int weight,double bmi, AVLTree t)
{
   if (t == NULL)
   {
      t = malloc(sizeof(struct Node));
      if (t == NULL) {
         printf("Out of memory space!!!\n");
         exit(1);
      }
      else
      {
         strcpy(t->fName, fName);
         strcpy(t->lName, lName);
         t->birthDate[0] = birthDate[0];
         t->birthDate[1] = birthDate[1];
         t->birthDate[2] = birthDate[2];
         t->height = height;
         t->weight = weight;
         t->bmi = bmi;
         t->treeHeight = 0;
         t->left = t->right = NULL;
         t->equalBMI = NULL;
      }
   }
   else if(bmi==t->bmi) {
      AVLTree newEqualBMI=(AVLTree)malloc(sizeof(struct Node));//initializes a tree to keep data of person with same BMI.
      if (newEqualBMI==NULL){
         printf("Out of memory space!!!\n");
         exit(1);
      }
      strcpy(newEqualBMI->fName, fName);
      strcpy(newEqualBMI->lName, lName);
      newEqualBMI->birthDate[0] = birthDate[0];
      newEqualBMI->birthDate[1] = birthDate[1];
      newEqualBMI->birthDate[2] = birthDate[2];
      newEqualBMI->height = height;
      newEqualBMI->weight = weight;
      newEqualBMI->bmi = bmi;
      newEqualBMI->right=NULL;//not used
      newEqualBMI->left=NULL;//not used
      newEqualBMI->equalBMI=NULL;//will be used like a pointer in linked lists.
      if(t->equalBMI==NULL)
         t->equalBMI=newEqualBMI;
      else {
         AVLTree tmp = t->equalBMI;
         while(tmp->equalBMI!=NULL)
            tmp=tmp->equalBMI;
         tmp->equalBMI=newEqualBMI;//traverse the existing equalBMI patients, if any, and inserts at the end.
      }
   }
   else if (bmi<t->bmi)
   {
      t->left = InsertElement(fName, lName, birthDate, height, weight, bmi, t->left);

      if (AVLTreeHeight(t->left) - AVLTreeHeight(t->right) == 2) {
         if (bmi < t->left->bmi)
            t = RotationLL(t);
         else
            t = RotationLR(t);
      }

   }
   else if (bmi>t->bmi)
   {
      t->right = InsertElement(fName, lName, birthDate, height, weight, bmi, t->right);
      if (AVLTreeHeight(t->right) - AVLTreeHeight(t->left) == 2) {
         if (bmi > t->right->bmi)
            t = RotationRR(t);
         else
            t = RotationRL(t);
      }
   }
   t->treeHeight = Max(AVLTreeHeight(t->left), AVLTreeHeight(t->right)) + 1;
   return t;
}

AVLTree loadPatients(char* fileName) {
   AVLTree t = CreateTree();
   FILE* inFile = fopen(fileName, "r");
   if(inFile == NULL) {
      printf("File could not be opened\n");
      exit (1);
   }
   char fName[20], lName[20];
   int birthDate[3];
   double height, bmi;
   int weight;//placeholders for fetched values from file.
   while (fscanf(inFile, "%20[^;];%20[^;];%d/%d/%d;%lf;%d;%lf\n", fName, lName, &birthDate[0], &birthDate[1], &birthDate[2], &height, &weight, &bmi) != EOF) {
      t=InsertElement(fName, lName, birthDate, height, weight, bmi,t);//pass the lines of the file as one node of a tree, one by one, until we reach the end of the file.
   }
   return t;
}

void DisplayEquals(AVLTree t) {
   if (t!=NULL) {
      printf("%s %s %d/%d/%d %.2lf %d %.2lf\n",t->fName,t->lName,t->birthDate[0],t->birthDate[1],t->birthDate[2],t->height,t->weight,t->bmi);
      DisplayEquals(t->equalBMI); //solely used for displaying patients that arent in the 'main' tree, but a part of a node already existing in the tree.
   }
}
void displayPatients(AVLTree t){
   if(t!=NULL) {
      displayPatients(t->left);
      DisplayEquals(t->equalBMI);
      printf("%s %s %d/%d/%d %.2lf %d %.2lf\n",t->fName,t->lName,t->birthDate[0],t->birthDate[1],t->birthDate[2],t->height,t->weight,t->bmi);
      displayPatients(t->right);
      //printing patients with in-order traversal.
   }
}

AVLTree RotationRR(AVLTree t)//Left rotation
{
   AVLTree j,k;
   j=t;
   k=t->right;
   j->right=k->left;
   k->left=j;
   j->treeHeight=Max(AVLTreeHeight(j->left),AVLTreeHeight(j->right))+1;
   k->treeHeight=Max(AVLTreeHeight(k->left),AVLTreeHeight(k->right))+1;
   return k;
}

AVLTree RotationLL(AVLTree t)//Right rotation
{
   AVLTree j,k;
   j=t;
   k=t->left;
   j->left=k->right;
   k->right=j;
   j->treeHeight=Max(AVLTreeHeight(j->left),AVLTreeHeight(j->right))+1;
   k->treeHeight=Max(AVLTreeHeight(k->left),AVLTreeHeight(k->right))+1;
   return k;
}

AVLTree RotationLR(AVLTree t)
{
   t->left=RotationRR(t->left);
   return RotationLL(t);
}

AVLTree RotationRL(AVLTree t)
{
   t->right=RotationLL(t->right);
   return RotationRR(t);
}

int infoPatient(AVLTree t, double searchBMI) {
   if (t==NULL)
      return -1; //base/empty tree condition
   if (t->bmi==searchBMI) {
      printf("%s %s %d/%d/%d %.2lf %d %.2lf\n",t->fName,t->lName,t->birthDate[0],t->birthDate[1],t->birthDate[2],t->height,t->weight,t->bmi);
      if (t->equalBMI!=NULL) {
         AVLTree tmp = t->equalBMI;
         while(tmp!=NULL) {
            printf("%s %s %d/%d/%d %.2lf %d %.2lf\n",tmp->fName,tmp->lName,tmp->birthDate[0],tmp->birthDate[1],tmp->birthDate[2],tmp->height,tmp->weight,tmp->bmi);
            tmp=tmp->equalBMI;
         }
      }
      return 1;
   }
   else if (t->bmi>searchBMI && t->left!=NULL)//binary search is conducted
      return infoPatient(t->left, searchBMI);
   else if (t->bmi<searchBMI && t->right!=NULL)
      return infoPatient(t->right, searchBMI);
   /* since we are using binary search to find an element, this function has the time complexity O(logn)
      since the tree is also sorted based on BMI (our search condition), there isnt a lot we can do to speed
      up the search process.*/
}

AVLTree youngestPatient(AVLTree t, AVLTree youngestP) {
   if (t==NULL)
      return youngestP;
   else if (t->birthDate[2]>youngestP->birthDate[2] || ((t->birthDate[2]==youngestP->birthDate[2]) && (t->birthDate[1]>youngestP->birthDate[1])) || ((t->birthDate[2]==youngestP->birthDate[2]) && ((t->birthDate[1]==youngestP->birthDate[1])) && ((t->birthDate[0]>youngestP->birthDate[0])))) {
      youngestP = t;
      /*compares the birth year, month and day of the current youngest patient to the node we are at in the tree.
        in the first step, this is redundant beceause the youngest is set to the root by default. However, as we traverse,
        we need to compare the root (or whatever the youngest patient becomes) to other patients in the tree.
        the comparison is done by first seeing if the current node's year value is larger. If it is, its automatically
        younger. If it is equal, the month is checked. The same process is repeated for the day as well, so we can
        appropriately determine if the current node is younger than the current younger patient.
      */
   }
   if (t->equalBMI!=NULL) {
      AVLTree tmp = t->equalBMI;
      while (tmp != NULL) {
         if (tmp->birthDate[2]>youngestP->birthDate[2] || ((tmp->birthDate[2]==youngestP->birthDate[2]) && (tmp->birthDate[1]>youngestP->birthDate[1]) || ((tmp->birthDate[2]==youngestP->birthDate[2]) && (tmp->birthDate[1]==youngestP->birthDate[1]) && (tmp->birthDate[0]>youngestP->birthDate[0])))) {
            youngestP = tmp;
         }
         tmp = tmp->equalBMI;
         /*the same process as the previous if statement comparing the current node to the current youngest patient, however
           for every node, we need to check the other patients contained within that node (those who share the same BMI) and
           compare their birthday to the current youngest patient as well. This is to ensure that we compare all patients.
         */
      }
   }
   youngestP=youngestPatient(t->left, youngestP);//recursive calls to check for every node's left and right children until all nodes are visited.
   youngestP=youngestPatient(t->right, youngestP);//it is important to notice that for every recursive call, we are using the same variable 'youngestP' to keep track of it and compare it with all other nodes.
   return youngestP;
   /*for this function, I had to visit every node in the tree because there was no sorting done according to birthdays.
    therefore, it has a complexity of O(N). This procedure would have been faster if there was a separate tree sorted by
    birthdays.*/
}

int AVLTreeHeight(AVLTree t)
{
   if (t == NULL)
      return -1;
   else
      return t->treeHeight;
}

int Max(int x, int y) {
   if (x >= y)
      return x;
   else
      return y;
}
